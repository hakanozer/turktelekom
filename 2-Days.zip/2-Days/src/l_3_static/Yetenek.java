package l_3_static;

public class Yetenek {
	
	static String section = "4.Section";

}
