package l_3_static;

public class L_3_Main {

	public static void main(String[] args) {
		
		String name = "Erdal";
		
		Yetenek.section = "5.Section";
		System.out.println(Yetenek.section);
		

	}

}
