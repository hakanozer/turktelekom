package l_6_interface;

public interface IUser {
	
	boolean userLogin(String email, String password);
	boolean userRegister( String name, String email, String password );
	

}
