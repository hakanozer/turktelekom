package l_6_interface;

public class MainInterface {

	public static void main(String[] args) {
		
		User user = new User();
		user.userLogin("ali@ali.com", "12345");
		
		user.userRegister("Ali", "ali@erkan.com", "12345");

	}

}
