package l_6_interface;

public interface ISecurity {
	
	String md5(String password);

}
