package l_6_interface;

public class User implements IUser, ISecurity {

	@Override
	public boolean userLogin(String email, String password) {
		if ( email.equals("ali@ali.com") && password.equals("12345")) {
			return true;
		}
		return false;
	}

	
	@Override
	public boolean userRegister(String name, String email, String password) {
		
		String md5 = md5(password);
		System.out.println(md5);
		
		return false;
	}


	@Override
	public String md5(String password) {
		try {
	        java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
	        byte[] array = md.digest(password.getBytes());
	        StringBuffer sb = new StringBuffer();
	        for (int i = 0; i < array.length; ++i) {
	          sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1,3));
	       }
	        return sb.toString();
	    } catch (java.security.NoSuchAlgorithmException e) {
	    }
	    return null;
	}

}
