package appPack;

import java.util.ArrayList;
import java.util.List;

import l_1_inheritance.A;
import l_1_inheritance.B;
import l_1_inheritance.Base;
import l_1_inheritance.C;

public class MainApp {

	public static void main(String[] args) {
		
		Base obj = new Base();
		Base a = new A();
		Base b = new B();
		Base c = new C();
		
		fncCall(obj);
		fncCall(a);
		fncCall(b);
		fncCall(c);
		
		
		Base ax = new A();
		A ay = new A();
		
		ArrayList<String> lsx = new ArrayList<>();
		List<String> ls = new ArrayList<>();
		
		
		// En Capsul
		L_2_final_private final_private = new L_2_final_private();
		//final_private.name = "Serkan";
		System.out.println(final_private.name);
	}

	public static void fncCall( Base base ) {
		base.call();
	}
	


	
	
}
