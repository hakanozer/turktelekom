package appPack;

public class L_2_final_private {
	
	protected final String name = "Erkan";
	
	private int age = 35;
	
	public void callAge() {
		System.out.println(age);
	}
	

}
