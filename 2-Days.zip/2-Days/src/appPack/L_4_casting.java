package appPack;

public class L_4_casting {

	public static void main(String[] args) {

		try {

			String stAge = "35";

			int cInt = Integer.parseInt(stAge);

			int sum = cInt + 20;

			System.out.println("Sm : " + sum);
			
			String ondalikString = "45.6"; 
			
			double ondalik = Double.valueOf(ondalikString);
			
			ondalik = ondalik + 12.5;
			System.out.println(ondalik);

		} catch (Exception e) {
			System.err.println("Casting Error : " + e);
		}
		
		System.out.println("Main  Call");

	}

}
