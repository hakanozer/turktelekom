package appPack;

public class X extends L_2_final_private {

	public void subFnc() {
		System.out.println(name);
	}
	
}
