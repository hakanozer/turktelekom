package l_5_fileusing;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Control {
	
	String filePath = "note.txt";
	
	public void create() {
		try {
			
			File file = new File(filePath);
			if ( !file.exists() ) { // file control
				file.createNewFile();
			}
			
		} catch (Exception e) {
			System.err.println("File Create Error : " + e);
		}
	}
	
	
	public void delete() {
		try {
			File file = new File(filePath);
			if ( file.exists() ) { // file control
				file.delete();
			}
		} catch (Exception e) {
			System.err.println("File delete Error : " + e);
		}
	}
	
	
	public void write(String data) {
		try {
			File file = new File(filePath);
			FileWriter writer = new FileWriter(file, true);
			writer.append(data);
			writer.append(System.lineSeparator());
			writer.close(); // save file
		} catch (Exception e) {
			System.err.println("File write Error : " + e);
		}
	}
	
	
	public List<String> read() {
		List<String> ls = new ArrayList<>();
		try {
			File file = new File(filePath);
			Scanner read = new Scanner(file);
			
			// satır sayısı
			while( read.hasNext() ) {
				String line = read.nextLine();
				//System.out.println(line);
				ls.add(line);
			}
			
			read.close();
			
		} catch (Exception e) {
			System.err.println("File read Error : " + e);
		}
		
		return ls;
	}
	
	
	public void extraDelete(String path) {
		try {
			File file = new File(path);
			if ( file.exists() ) { // file control
				file.delete();
			}
		} catch (Exception e) {
			System.err.println("File delete Error : " + e);
		}
	}

}
