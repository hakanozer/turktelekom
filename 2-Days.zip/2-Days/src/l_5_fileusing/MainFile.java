package l_5_fileusing;

import java.io.File;
import java.util.List;
import java.util.Scanner;

public class MainFile {

	public static void main(String[] args) {
		
		Control control = new Control();
		
		//control.create();
		//control.delete();
		//control.write("Merhaba Java");
		
		Scanner scanner = new Scanner(System.in);
		for (int i = 0; i < 1000; i++) {
			System.out.println("Lütfen değer giriniz!, Çıkış: xx");
			String pullData = scanner.nextLine();
			if ( pullData.equals("xx") ) {
				break;
			}
			control.write(pullData);
		}
		
		
		List<String> ls = control.read();
		System.out.println(ls);
		
		
		// extraPath Remove
		
		String path = "/Users/hakan/Desktop/files";
		File file = new File(path);
		File[] arr = file.listFiles();
		for (File item : arr) {
			String pth = item.getAbsolutePath();
			System.out.println(pth);
			control.extraDelete(pth);
		}

		
		

	}

}
