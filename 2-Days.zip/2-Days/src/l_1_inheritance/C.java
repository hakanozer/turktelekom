package l_1_inheritance;

public class C extends A {

	@Override
	public void call() {
		
		System.out.println("C Class Call");
		action(50, 10);
		super.action(50, 10);
		
	}
	
	@Override
	public void action(int a, int b) {
		int ac = a * b;
		System.out.println("C Action : " + ac);
	}
	
}
