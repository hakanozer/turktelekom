package l_1_inheritance;

public class Base {
	
	public int number = 10;
	public String name = "Serkan";
	
	public void call() {
		System.out.println("Fnc Base Call");
	}
	
	public void action( int a, int b ) {
		int ac = a + b;
		System.out.println("Sum : " + ac);
	}

}
