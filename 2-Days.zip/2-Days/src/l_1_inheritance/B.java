package l_1_inheritance;

public class B extends Base {

	@Override
	public void call() {
		
		System.out.println("B Class Call");
		
	}
	
}
