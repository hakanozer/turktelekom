package tr.com.turktelekom;

import java.util.Scanner;

public class L_1_IF {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Lütfen adınızı Giriniz!");
		
		String name = scanner.nextLine();
		
		if ( name.equals("ali") ) { // name == "ali"
			System.out.println("Girilen Değer Doğru");
		}else {
			System.out.println("Girilen değer hatalı!");
		}
		

	}

}
