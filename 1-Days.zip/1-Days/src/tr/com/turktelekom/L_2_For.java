package tr.com.turktelekom;

public class L_2_For {
	
	
	public static void main(String[] args) {
		
		// Arrays
		String single_name = "Ali";
		
		String[] names = { "Ali", "Veli", "Hasan", "Mehmet" };
		
		System.out.println(single_name);
		System.out.println( names[3] );
		
		
		for( int i = 0; i < names.length; i++ ) {
			
			String data = names[i];
			if ( data.equals("Ali") ) {
				System.out.println("Ali'yi İşleme Koyma");
			}else {
				System.out.println(data);
			}
			
			
		}
		
		
		
		
	}
	

}
