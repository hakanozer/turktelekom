package tr.com.turktelekom;

import java.util.List;

public class Yetenek {
	
	int number = 0;
	
	public Yetenek() {
		System.out.println("Yetenek Call");
	}

	public Yetenek ( int number ) {
		this.number = number;
	}
	
	public Yetenek ( int number, String name ) {
		this.number = number;
	}
	
	public void loop() {
		for (int i = 0; i < number; i++) {
			System.out.println("i : " + i);
		}
	}
	
	
	
	

}
