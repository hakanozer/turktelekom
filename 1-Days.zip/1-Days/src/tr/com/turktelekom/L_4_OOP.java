package tr.com.turktelekom;

import java.util.ArrayList;

public class L_4_OOP {
	
	int age = 30;

	public static void main(String[] args) {
		
		
		// nesne - Object
		Action obj = new Action();
		obj.noParameter();
		
		// Parameter Fnc Call
		obj.parameter(60, 100);
		obj.parameter(55, 77);
		obj.parameter(44, 33);
		
		// return fnc Call
		int sm = obj.sum(500, 387);
		System.out.println("Sum : " + sm);
		if ( sm > 500) {
			System.out.println("sınır aşıldı");
		}
		
		// number?
		System.out.println("obj Number : " + obj.number);

		
		Action ac = new Action();
		System.out.println("ac Number : " + ac.number);
		
		
		// Kurucu methodlar
		Yetenek yetenek = new Yetenek(10);
		yetenek.loop();
		
		
		ArrayList<Data> ls = new ArrayList<Data>();
		
		
	}

}
