package tr.com.turktelekom;

public class Action {
	
	int number = 0;
	
	
	public Action() {
		System.out.println("Action Call");
	}
	
	// no Parameter and Return
	public void noParameter() {
		System.out.println("noParameter Call");
	}
	
	// no Return
	public void parameter( int number1, int number2 ) {
		number = number1 + number2;
		System.out.println("Sum - : " + number);
	}
	
	
	// return
	/**
	 * İki sayıyı toplayan fonksiyon
	 * @param number1 - toplanacak 1. sayı
	 * @param number2 - toplanacak 2. sayı
	 * @return - Toplam sonucu (int) döner
	 * @author - Ali Bilmem
	 * <br/>
	 * <img width="250" src="https://miro.medium.com/max/512/0*NNFnKPCJGIEnaHdc" />
	 */
	public int sum( int number1, int number2 ) {
		return number1 + number2;
	}

}
