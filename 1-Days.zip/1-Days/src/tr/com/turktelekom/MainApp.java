package tr.com.turktelekom;

public class MainApp {

	public static void main(String[] args) {
		
		
		// Değişkenler
		System.out.println("MainApp Call");
		
		// String
		// Adınız, Takın, Nick, ...
		String name = "Ali Bilmem";
		String nick = "19Ali";
		System.out.println(name  + nick);
		
		// Tam sayılar
		int age = 35;
		
		// Byte -> küçük sayısal türler
		byte number = 127;
		
		// Ondalıklı değerler
		double ondalik = 10.5;
		
		// True - false
		boolean status = true;
		
		
		// Sum
		int numberx = 40;
		int numbery = 50;
		int sum = numberx + numbery;
		System.out.println("Sum : " + sum);

	}

}
