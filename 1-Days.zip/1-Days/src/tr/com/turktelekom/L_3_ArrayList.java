package tr.com.turktelekom;

import java.util.ArrayList;
import java.util.Scanner;

public class L_3_ArrayList {

	public static void main(String[] args) {

		// ArrayList
		ArrayList<String> ls = new ArrayList<>();
		
		// Item Add
		ls.add("İstanbul");
		ls.add("Bursa");
		ls.add("Edirne");
		ls.add("Tekirdağ");
		
		System.out.println("ls : " + ls);
		
		// size
		int size = ls.size();
		System.out.println("Size : " + size);
		
		
		// single item
		String item = ls.get(0);
		System.out.println(item);
		
		
		System.out.println("========================");
		int i = 0;
		// all items print
		for ( i = 0; i<ls.size(); i++ ) {
			System.out.println(  ls.get(i)  );			
		}
		System.out.println("i " + i);

		
		// Scanner with data
		Scanner scanner = new Scanner(System.in);
		for (int j = 0; j < 5; j++) {
			System.out.println("City Add : " + j);
			String city = scanner.nextLine();
			ls.add(city);
		}

		
		ls.remove(0);
		ls.remove(0);
		// ls.clear(); // all items clear
		System.out.println(ls);
		
	}

}
