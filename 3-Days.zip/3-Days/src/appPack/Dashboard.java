package appPack;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Rectangle;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;
import javax.swing.JTextField;
import javax.swing.JEditorPane;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Dashboard extends JFrame {

	private JPanel contentPane;
	private JTextField txtTitle;
	private JTable table;
	private JEditorPane txtDetail;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dashboard frame = new Dashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	DB db = new DB();
	public Dashboard() {
		
		db.createNoteTable();
		db.noteAllResult();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 564, 382);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		
		JLabel lblNewLabel = new JLabel("Welcome Dashboard");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(404, 6, 154, 16);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Note Add", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(6, 34, 552, 146);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Title");
		lblNewLabel_1.setBounds(20, 28, 61, 16);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Detail");
		lblNewLabel_2.setBounds(20, 55, 61, 16);
		panel.add(lblNewLabel_2);
		
		txtTitle = new JTextField();
		txtTitle.setBounds(93, 23, 438, 26);
		panel.add(txtTitle);
		txtTitle.setColumns(10);
		
		JButton btnNewButton = new JButton("Add Note");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String title = txtTitle.getText();
				String detail = txtDetail.getText();
				
				int status = db.noteInsert(title, detail);
				if ( status > 0 ) {
					JOptionPane.showMessageDialog(getContentPane(), "Note Insert Success");
					
					txtTitle.setText("");
					txtDetail.setText("");
					txtTitle.requestFocus();
					
				}
			}
		});
		btnNewButton.setBounds(414, 111, 117, 29);
		panel.add(btnNewButton);
		
		txtDetail = new JEditorPane();
		txtDetail.setBounds(93, 55, 438, 48);
		panel.add(txtDetail);
		
		table = new JTable();
		
		JScrollPane scrollPane = new JScrollPane(table);
		int rowIndex = 20;
		int columnIndex = 0;
		boolean includeSpacing = true;
		Rectangle cellRect = table.getCellRect(rowIndex, columnIndex, includeSpacing);
		table.scrollRectToVisible(cellRect);
		
		//table.setBounds(6, 339, 552, -151);
		contentPane.add(scrollPane);
	}
}
