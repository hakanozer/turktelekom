package appPack;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.SwingConstants;
import javax.swing.JPasswordField;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField txtMail;
	private JPasswordField txtPass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
		
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Text içindeki değeri alma
				String email = txtMail.getText();
				char[] passArr = txtPass.getPassword();
				String pass = String.valueOf(passArr);
				
				// ali@ali.com - 12345
				if ( email.equals("ali@ali.com") && pass.equals("12345") ) {
					// kullanıcı adı ve şifre doğru
					JOptionPane.showMessageDialog(getRootPane(), "Giriş Başarılı.");
					
					// Dashboard Class show
					Dashboard dashboard = new Dashboard();
					dashboard.setVisible(true);
					
					
					// dispose -> mevcut sınıfı artık öldür.
					contentPane.setVisible(false);
					dispose();
					
					
				}else {
					// kullanıcı adı yada şifre hatalı!
					JOptionPane.showMessageDialog(getRootPane(), "Kullanıcı Adı yada Şifre Hatalı!");
				}
				
			}
		});
		btnLogin.setBounds(289, 152, 117, 29);
		contentPane.add(btnLogin);
		
		txtMail = new JTextField();
		txtMail.setBounds(118, 80, 290, 26);
		contentPane.add(txtMail);
		txtMail.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("User Login");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 16));
		lblNewLabel.setBounds(42, 38, 366, 30);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("E-Mail");
		lblNewLabel_1.setBounds(45, 85, 61, 16);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Password");
		lblNewLabel_1_1.setBounds(45, 119, 61, 16);
		contentPane.add(lblNewLabel_1_1);
		
		txtPass = new JPasswordField();
		txtPass.setBounds(118, 118, 288, 26);
		contentPane.add(txtPass);
	}
}
