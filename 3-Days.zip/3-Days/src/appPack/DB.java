
package appPack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DB {
    
    
    final private String driver = "org.h2.Driver";
    final private String url = "jdbc:h2:file:/Users/hakan/Documents/telekom/3-Days/db/proje";
    final private String dbUserName = "sa";
    final private String dbUserPass = "";
    
    
    private Connection conn = null;
    private PreparedStatement pre = null;
    
    
    public PreparedStatement con( String query ) {
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, dbUserName, dbUserPass);
            pre = conn.prepareStatement(query);
            System.out.println("Connection Success");
        } catch (Exception e) {
            System.err.println("Connection Error : " + e);
        }
        return pre;
    }
    
    
    public void close() {
        try {
            conn.close();
            pre.close();
        } catch (Exception e) {
            System.err.println("Close Error : " + e);
        }
    }
    
    
    
    public void createNoteTable() {
    	String query = "CREATE TABLE IF NOT EXISTS note(\n"
    			+ "nid int auto_increment, \n"
    			+ "title varchar(255),\n"
    			+ "detail varchar(255)\n"
    			+ ");";
    	try {
        	PreparedStatement pre = con(query);
        	pre.executeUpdate();
		} catch (Exception e) {
			System.err.println("CreateNoteTable Error : " + e);
		}
    	
    	close();
    }
    
    
    public int noteInsert( String title, String detail ) {
    	int status = 0;
    	try {
    		// ' or 1=1 delete form note --
			// insert into note values ( null, 'sinema', '' or 1=1 delete form note --' )
    		String query = "insert into note values( null, ?, ? )  ";
    		PreparedStatement pre = con(query);
    		pre.setString(1, title);
    		pre.setString(2, detail);
    		status = pre.executeUpdate();
    		
		} catch (Exception e) {
			System.err.println("noteInsert Error : " + e);
		}
    	close();
    	return status;
    }
    
    
    public void noteAllResult() {
    	
    	try {
			String query = "select * from note";
			PreparedStatement pre = con(query);
			ResultSet rs = pre.executeQuery();
			while( rs.next() ) {
				int nid = rs.getInt("nid");
				String title = rs.getString("title");
				String detail = rs.getString("detail");
				System.out.println(nid + " " + title + " " + detail);
			}
			close();
		} catch (Exception e) {
			System.err.println("noteAllResult Error : " + e);
		}
    	
    }
    
    
    
}
